Premier Express Governed SEO Bridge

Purpose
-------
This plugin provides a very small REST bridge for the Premier Express autonomous SEO agent.

Safety defaults
---------------
- Write mode is OFF after installation.
- Only WordPress-authenticated users who can edit the target post/product may use the endpoint.
- Only two fields are writable: Yoast SEO title and Yoast meta description.
- Every write request must include the previously captured before-state.
- Dry-run mode is the default.
- A mismatch between live state and captured before-state returns HTTP 409 and performs no write.

Install
-------
WordPress Admin > Plugins > Add New Plugin > Upload Plugin > choose the ZIP > Install > Activate.

After activation
----------------
Settings > Premier SEO Bridge

Keep “Enable governed SEO writes” OFF until the agent execution flow is fully verified.
