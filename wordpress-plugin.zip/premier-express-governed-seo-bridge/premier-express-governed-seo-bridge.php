<?php
/**
 * Plugin Name: Premier Express Governed SEO Bridge
 * Description: Minimal approval-oriented REST bridge for safely reading and updating Yoast SEO title/meta description for Premier Express Tourism.
 * Version: 1.0.0
 * Author: Premier Express Tourism LLC
 */

if ( ! defined( 'ABSPATH' ) ) exit;

final class Premier_Express_Governed_SEO_Bridge {
    const NS = 'premier-agent/v1';
    const OPTION_WRITE = 'premier_agent_seo_write_enabled';

    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
        add_action( 'admin_menu', [ __CLASS__, 'settings_page' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_setting' ] );
    }

    public static function register_setting() {
        register_setting(
            'premier_agent_seo_bridge',
            self::OPTION_WRITE,
            [
                'type' => 'boolean',
                'sanitize_callback' => function( $v ) { return (bool) $v; },
                'default' => false,
            ]
        );
    }

    public static function settings_page() {
        add_options_page(
            'Premier SEO Bridge',
            'Premier SEO Bridge',
            'manage_options',
            'premier-seo-bridge',
            [ __CLASS__, 'render_settings' ]
        );
    }

    public static function render_settings() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap">
            <h1>Premier Express Governed SEO Bridge</h1>
            <p>This bridge exposes only Yoast SEO title and meta description to authenticated WordPress users who can edit the target post/product.</p>
            <form method="post" action="options.php">
                <?php settings_fields( 'premier_agent_seo_bridge' ); ?>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr( self::OPTION_WRITE ); ?>" value="1" <?php checked( get_option( self::OPTION_WRITE, false ) ); ?>>
                    Enable governed SEO writes
                </label>
                <p class="description">Leave disabled until the Premier Express execution ledger, rollback capture and verification flow are ready.</p>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function routes() {
        register_rest_route( self::NS, '/capabilities', [
            'methods' => 'GET',
            'callback' => [ __CLASS__, 'capabilities' ],
            'permission_callback' => function() { return is_user_logged_in(); },
        ] );

        register_rest_route( self::NS, '/seo/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [ __CLASS__, 'read_seo' ],
                'permission_callback' => [ __CLASS__, 'can_edit_target' ],
            ],
            [
                'methods' => [ 'POST', 'PATCH' ],
                'callback' => [ __CLASS__, 'write_seo' ],
                'permission_callback' => [ __CLASS__, 'can_edit_target' ],
                'args' => [
                    'seo_title' => [ 'required' => false, 'type' => 'string' ],
                    'meta_description' => [ 'required' => false, 'type' => 'string' ],
                    'expected_before' => [ 'required' => true, 'type' => 'object' ],
                    'dry_run' => [ 'required' => false, 'type' => 'boolean', 'default' => true ],
                ],
            ],
        ] );
    }

    public static function can_edit_target( WP_REST_Request $request ) {
        $id = absint( $request['id'] );
        return $id > 0 && get_post( $id ) && current_user_can( 'edit_post', $id );
    }

    private static function state( $id ) {
        return [
            'id' => (int) $id,
            'post_type' => get_post_type( $id ),
            'permalink' => get_permalink( $id ),
            'seo_title' => (string) get_post_meta( $id, '_yoast_wpseo_title', true ),
            'meta_description' => (string) get_post_meta( $id, '_yoast_wpseo_metadesc', true ),
            'write_enabled' => (bool) get_option( self::OPTION_WRITE, false ),
        ];
    }

    public static function capabilities() {
        return rest_ensure_response( [
            'success' => true,
            'bridge' => 'premier-express-governed-seo-bridge',
            'version' => '1.0.0',
            'fields' => [ 'seo_title', 'meta_description' ],
            'yoast_active' => defined( 'WPSEO_VERSION' ),
            'write_enabled' => (bool) get_option( self::OPTION_WRITE, false ),
            'authentication' => 'WordPress authenticated user / Application Password',
            'guardrails' => [
                'edit_post_capability_required',
                'expected_before_required',
                'dry_run_default_true',
                'field_allowlist_only',
            ],
        ] );
    }

    public static function read_seo( WP_REST_Request $request ) {
        $id = absint( $request['id'] );
        return rest_ensure_response( [
            'success' => true,
            'state' => self::state( $id ),
        ] );
    }

    private static function expected_matches( $current, $expected ) {
        foreach ( [ 'seo_title', 'meta_description' ] as $field ) {
            if ( array_key_exists( $field, $expected ) ) {
                if ( (string) $current[$field] !== (string) $expected[$field] ) {
                    return false;
                }
            }
        }
        return true;
    }

    public static function write_seo( WP_REST_Request $request ) {
        $id = absint( $request['id'] );
        $dry_run = filter_var( $request->get_param( 'dry_run' ), FILTER_VALIDATE_BOOLEAN );
        $expected = (array) $request->get_param( 'expected_before' );
        $current = self::state( $id );

        if ( ! self::expected_matches( $current, $expected ) ) {
            return new WP_Error(
                'premier_seo_state_conflict',
                'Live SEO state no longer matches the captured before-state. Re-capture before executing.',
                [ 'status' => 409, 'current' => $current ]
            );
        }

        $changes = [];
        if ( $request->has_param( 'seo_title' ) ) {
            $changes['seo_title'] = sanitize_text_field( (string) $request->get_param( 'seo_title' ) );
        }
        if ( $request->has_param( 'meta_description' ) ) {
            $changes['meta_description'] = sanitize_textarea_field( (string) $request->get_param( 'meta_description' ) );
        }
        if ( empty( $changes ) ) {
            return new WP_Error( 'premier_seo_no_fields', 'No allowed SEO fields supplied.', [ 'status' => 400 ] );
        }

        if ( $dry_run ) {
            return rest_ensure_response( [
                'success' => true,
                'dry_run' => true,
                'before' => $current,
                'intended' => array_merge( $current, $changes ),
                'write_performed' => false,
            ] );
        }

        if ( ! get_option( self::OPTION_WRITE, false ) ) {
            return new WP_Error(
                'premier_seo_write_disabled',
                'Governed SEO writes are disabled in WordPress settings.',
                [ 'status' => 403 ]
            );
        }

        if ( array_key_exists( 'seo_title', $changes ) ) {
            if ( $changes['seo_title'] === '' ) delete_post_meta( $id, '_yoast_wpseo_title' );
            else update_post_meta( $id, '_yoast_wpseo_title', $changes['seo_title'] );
        }
        if ( array_key_exists( 'meta_description', $changes ) ) {
            if ( $changes['meta_description'] === '' ) delete_post_meta( $id, '_yoast_wpseo_metadesc' );
            else update_post_meta( $id, '_yoast_wpseo_metadesc', $changes['meta_description'] );
        }

        clean_post_cache( $id );
        $after = self::state( $id );

        return rest_ensure_response( [
            'success' => true,
            'dry_run' => false,
            'before' => $current,
            'after' => $after,
            'write_performed' => true,
        ] );
    }
}

Premier_Express_Governed_SEO_Bridge::init();
